﻿namespace Daugiagijis_Porjektas
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button11 = new Button();
            button12 = new Button();
            dataGridView2 = new DataGridView();
            button13 = new Button();
            button14 = new Button();
            button15 = new Button();
            dataGridView3 = new DataGridView();
            button16 = new Button();
            button17 = new Button();
            button18 = new Button();
            button19 = new Button();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToResizeColumns = false;
            dataGridView1.AllowUserToResizeRows = false;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(132, 28);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(458, 305);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // button1
            // 
            button1.Location = new Point(12, 28);
            button1.Name = "button1";
            button1.Size = new Size(114, 23);
            button1.TabIndex = 1;
            button1.Text = "+1 Eilutę";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(12, 86);
            button2.Name = "button2";
            button2.Size = new Size(114, 23);
            button2.TabIndex = 2;
            button2.Text = "+3 Eilutes";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(12, 144);
            button3.Name = "button3";
            button3.Size = new Size(114, 23);
            button3.TabIndex = 3;
            button3.Text = "+5 Eilutes";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Location = new Point(132, 339);
            button4.Name = "button4";
            button4.Size = new Size(101, 23);
            button4.TabIndex = 4;
            button4.Text = "+1 Stulpelis";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.Location = new Point(239, 339);
            button5.Name = "button5";
            button5.Size = new Size(101, 23);
            button5.TabIndex = 5;
            button5.Text = "+3 Stulpelius";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.Location = new Point(346, 339);
            button6.Name = "button6";
            button6.Size = new Size(101, 23);
            button6.TabIndex = 6;
            button6.Text = "+5 Stulpelius";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // button7
            // 
            button7.Location = new Point(651, 28);
            button7.Name = "button7";
            button7.Size = new Size(114, 23);
            button7.TabIndex = 13;
            button7.Text = "+1 Eilutę";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // button8
            // 
            button8.Location = new Point(651, 86);
            button8.Name = "button8";
            button8.Size = new Size(114, 23);
            button8.TabIndex = 12;
            button8.Text = "+3 Eilutes";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // button9
            // 
            button9.Location = new Point(651, 144);
            button9.Name = "button9";
            button9.Size = new Size(114, 23);
            button9.TabIndex = 11;
            button9.Text = "+5 Eilutes";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button9_Click;
            // 
            // button10
            // 
            button10.Location = new Point(771, 339);
            button10.Name = "button10";
            button10.Size = new Size(101, 23);
            button10.TabIndex = 10;
            button10.Text = "+1 Stulpelis";
            button10.UseVisualStyleBackColor = true;
            button10.Click += button10_Click;
            // 
            // button11
            // 
            button11.Location = new Point(878, 339);
            button11.Name = "button11";
            button11.Size = new Size(101, 23);
            button11.TabIndex = 9;
            button11.Text = "+3 Stulpelius";
            button11.UseVisualStyleBackColor = true;
            button11.Click += button11_Click;
            // 
            // button12
            // 
            button12.Location = new Point(985, 339);
            button12.Name = "button12";
            button12.Size = new Size(101, 23);
            button12.TabIndex = 8;
            button12.Text = "+5 Stulpelius";
            button12.UseVisualStyleBackColor = true;
            button12.Click += button12_Click;
            // 
            // dataGridView2
            // 
            dataGridView2.AllowUserToResizeColumns = false;
            dataGridView2.AllowUserToResizeRows = false;
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Location = new Point(771, 28);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.Size = new Size(458, 305);
            dataGridView2.TabIndex = 7;
            dataGridView2.CellContentClick += dataGridView2_CellContentClick;
            // 
            // button13
            // 
            button13.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button13.Location = new Point(461, 395);
            button13.Name = "button13";
            button13.Size = new Size(145, 35);
            button13.TabIndex = 15;
            button13.Text = "Sudėjimas";
            button13.UseVisualStyleBackColor = true;
            button13.Click += button13_Click;
            // 
            // button14
            // 
            button14.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button14.Location = new Point(612, 395);
            button14.Name = "button14";
            button14.Size = new Size(145, 35);
            button14.TabIndex = 16;
            button14.Text = "Atėjimas";
            button14.UseVisualStyleBackColor = true;
            button14.Click += button14_Click;
            // 
            // button15
            // 
            button15.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button15.Location = new Point(763, 395);
            button15.Name = "button15";
            button15.Size = new Size(145, 35);
            button15.TabIndex = 17;
            button15.Text = "Daugyba";
            button15.UseVisualStyleBackColor = true;
            button15.Click += button15_Click;
            // 
            // dataGridView3
            // 
            dataGridView3.AllowUserToResizeColumns = false;
            dataGridView3.AllowUserToResizeRows = false;
            dataGridView3.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView3.Location = new Point(450, 477);
            dataGridView3.Name = "dataGridView3";
            dataGridView3.ReadOnly = true;
            dataGridView3.Size = new Size(458, 305);
            dataGridView3.TabIndex = 18;
            dataGridView3.CellContentClick += dataGridView3_CellContentClick;
            // 
            // button16
            // 
            button16.Location = new Point(489, 339);
            button16.Name = "button16";
            button16.Size = new Size(101, 23);
            button16.TabIndex = 19;
            button16.Text = "-1 Stulpelis";
            button16.UseVisualStyleBackColor = true;
            button16.Click += button16_Click;
            // 
            // button17
            // 
            button17.Location = new Point(1128, 339);
            button17.Name = "button17";
            button17.Size = new Size(101, 23);
            button17.TabIndex = 20;
            button17.Text = "-1 Stulpelis";
            button17.UseVisualStyleBackColor = true;
            button17.Click += button17_Click;
            // 
            // button18
            // 
            button18.Location = new Point(12, 310);
            button18.Name = "button18";
            button18.Size = new Size(114, 23);
            button18.TabIndex = 21;
            button18.Text = "-1 Eilutę";
            button18.UseVisualStyleBackColor = true;
            button18.Click += button18_Click;
            // 
            // button19
            // 
            button19.Location = new Point(651, 310);
            button19.Name = "button19";
            button19.Size = new Size(114, 23);
            button19.TabIndex = 22;
            button19.Text = "-1 Eilutę";
            button19.UseVisualStyleBackColor = true;
            button19.Click += button19_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(621, 433);
            label1.Name = "label1";
            label1.Size = new Size(126, 32);
            label1.TabIndex = 23;
            label1.Text = "Atsakymas";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1241, 794);
            Controls.Add(label1);
            Controls.Add(button19);
            Controls.Add(button18);
            Controls.Add(button17);
            Controls.Add(button16);
            Controls.Add(dataGridView3);
            Controls.Add(button15);
            Controls.Add(button14);
            Controls.Add(button13);
            Controls.Add(button7);
            Controls.Add(button8);
            Controls.Add(button9);
            Controls.Add(button10);
            Controls.Add(button11);
            Controls.Add(button12);
            Controls.Add(dataGridView2);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(dataGridView1);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button12;
        private DataGridView dataGridView2;
        private Button button13;
        private Button button14;
        private Button button15;
        private DataGridView dataGridView3;
        private Button button16;
        private Button button17;
        private Button button18;
        private Button button19;
        private Label label1;
    }
}
