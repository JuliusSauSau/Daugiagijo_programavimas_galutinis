﻿using System;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Daugiagijis_Porjektas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;

            dataGridView1.ColumnCount = 1;
            dataGridView1.RowCount = 1;

            dataGridView2.ColumnCount = 1;
            dataGridView2.RowCount = 1;

            dataGridView1.AllowUserToAddRows = false;
            dataGridView2.AllowUserToAddRows = false;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Add();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 3; i++)
                dataGridView1.Rows.Add();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
                dataGridView1.Rows.Add();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            dataGridView1.Columns.Add("", "");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 3; i++)
                dataGridView1.Columns.Add("", "");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
                dataGridView1.Columns.Add("", "");
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            dataGridView2.Rows.Add();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 3; i++)
                dataGridView2.Rows.Add();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
                dataGridView2.Rows.Add();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            dataGridView2.Columns.Add("", "");
        }

        private void button11_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 3; i++)
                dataGridView2.Columns.Add("", "");
        }

        private void button12_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
                dataGridView2.Columns.Add("", "");
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private async void button13_Click(object sender, EventArgs e)
        {
            await Task.Run(() =>
            {
                PerformAddition();
            });
        }

        private async void button14_Click(object sender, EventArgs e)
        {
            await Task.Run(() =>
            {
                PerformSubtraction();
            });
        }

        private async void button15_Click(object sender, EventArgs e)
        {
            await Task.Run(() =>
            {
                PerformMultiplication();
            });
        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void PerformAddition()
        {
            int rows = dataGridView1.RowCount;
            int columns = dataGridView1.ColumnCount;

            if (rows != dataGridView2.RowCount || columns != dataGridView2.ColumnCount)
            {
                MessageBox.Show("Matrica A ir Matrica B turi turėti vienodą dydį.");
                return;
            }

            dataGridView3.Invoke((MethodInvoker)(() => dataGridView3.RowCount = rows));
            dataGridView3.Invoke((MethodInvoker)(() => dataGridView3.ColumnCount = columns));

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < columns; j++)
                {
                    if (dataGridView1.InvokeRequired || dataGridView2.InvokeRequired || dataGridView3.InvokeRequired)
                    {
                        int a = Convert.ToInt32(dataGridView1.Invoke(() => dataGridView1.Rows[i].Cells[j].Value));
                        int b = Convert.ToInt32(dataGridView2.Invoke(() => dataGridView2.Rows[i].Cells[j].Value));
                        dataGridView3.Invoke(() => dataGridView3.Rows[i].Cells[j].Value = a + b);
                    }
                    else
                    {
                        int a = Convert.ToInt32(dataGridView1.Rows[i].Cells[j].Value);
                        int b = Convert.ToInt32(dataGridView2.Rows[i].Cells[j].Value);
                        dataGridView3.Rows[i].Cells[j].Value = a + b;
                    }
                }
            }
        }

        private void PerformSubtraction()
        {
            int rows = dataGridView1.RowCount;
            int columns = dataGridView1.ColumnCount;

            if (rows != dataGridView2.RowCount || columns != dataGridView2.ColumnCount)
            {
                MessageBox.Show("Matrica A ir Matrica B turi turėti vienodą dydį.");
                return;
            }

            dataGridView3.Invoke((MethodInvoker)(() => dataGridView3.RowCount = rows));
            dataGridView3.Invoke((MethodInvoker)(() => dataGridView3.ColumnCount = columns));

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < columns; j++)
                {
                    if (dataGridView1.InvokeRequired || dataGridView2.InvokeRequired || dataGridView3.InvokeRequired)
                    {
                        int a = Convert.ToInt32(dataGridView1.Invoke(() => dataGridView1.Rows[i].Cells[j].Value));
                        int b = Convert.ToInt32(dataGridView2.Invoke(() => dataGridView2.Rows[i].Cells[j].Value));
                        dataGridView3.Invoke(() => dataGridView3.Rows[i].Cells[j].Value = a - b);
                    }
                    else
                    {
                        int a = Convert.ToInt32(dataGridView1.Rows[i].Cells[j].Value);
                        int b = Convert.ToInt32(dataGridView2.Rows[i].Cells[j].Value);
                        dataGridView3.Rows[i].Cells[j].Value = a - b;
                    }
                }
            }
        }

        private void PerformMultiplication()
        {
            int rows1 = dataGridView1.RowCount;
            int columns1 = dataGridView1.ColumnCount;
            int rows2 = dataGridView2.RowCount;
            int columns2 = dataGridView2.ColumnCount;

            if (columns1 != rows2)
            {
                MessageBox.Show("Matricų stulpelių ir eilučių skaičius nesuderinamas daugybai.");
                return;
            }

            dataGridView3.Invoke((MethodInvoker)(() => dataGridView3.RowCount = rows1));
            dataGridView3.Invoke((MethodInvoker)(() => dataGridView3.ColumnCount = columns2));

            for (int i = 0; i < rows1; i++)
            {
                for (int j = 0; j < columns2; j++)
                {
                    int sum = 0;

                    for (int k = 0; k < columns1; k++)
                    {
                        int a = Convert.ToInt32(dataGridView1.Invoke(() => dataGridView1.Rows[i].Cells[k].Value));
                        int b = Convert.ToInt32(dataGridView2.Invoke(() => dataGridView2.Rows[k].Cells[j].Value));
                        sum += a * b;
                    }

                    dataGridView3.Invoke(() => dataGridView3.Rows[i].Cells[j].Value = sum);
                }
            }
        }

        private void button16_Click(object sender, EventArgs e)
        {
            if (dataGridView1.ColumnCount > 0)
            {
                dataGridView1.Columns.RemoveAt(dataGridView1.ColumnCount - 1);
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            if (dataGridView2.ColumnCount > 0)
            {
                dataGridView2.Columns.RemoveAt(dataGridView2.ColumnCount - 1);
            }
        }

        private void button18_Click(object sender, EventArgs e)
        {
            if (dataGridView1.RowCount > 0)
            {
                dataGridView1.Rows.RemoveAt(dataGridView1.RowCount - 1);
            }
        }

        private void button19_Click(object sender, EventArgs e)
        {
            if (dataGridView2.RowCount > 0)
            {
                dataGridView2.Rows.RemoveAt(dataGridView2.RowCount - 1);
            }
        }
    }
}
